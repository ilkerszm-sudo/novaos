# NovaOS

Hobby x86_64 OS, booted by Limine (v8.x), run in QEMU.

## Setup
**Debian/Ubuntu/WSL2:** `sudo apt install build-essential nasm xorriso qemu-system-x86 git curl`
**macOS:** `brew install nasm xorriso qemu git x86_64-elf-gcc`
**Linux without a cross-compiler:** host gcc works: `make ARCH_PREFIX=` (and `LD=ld`).
Cross-compiler on Linux: build binutils+gcc for `x86_64-elf`, or `brew install x86_64-elf-gcc` (Linuxbrew).

## Build & run
    make            # builds kernel.elf (first run clones Limine)
    make iso        # novaos.iso (BIOS+UEFI)
    make run        # QEMU; kernel log appears in this terminal via COM1

## Status
Milestone 1, part 1: boot, GDT/TSS, IDT, PIC, PIT, bitmap PMM, serial, panic, framebuffer gradient.
Next (part 2): paging/VMM, kernel heap, PS/2 kbd+mouse. Part 3: scheduler, syscalls, ring 3, ELF.

## Design notes
- Limine puts us in long mode with paging on and all RAM mapped at the HHDM offset; we reuse that until the VMM part.
- GDT order is forced by SYSCALL/SYSRET (see gdt.c). #DF runs on its own IST stack.
- Interrupt frame is 16-byte aligned at the C call (CPU frame 40B + err + vector + 15 GPRs).
- Test a panic: uncomment the divide-by-zero line in main.c.
