#include <stdint.h>
#include "string.h"
void *memcpy(void *d, const void *s, size_t n){
    uint8_t *dp=d; const uint8_t *sp=s; while(n--) *dp++=*sp++; return d; }
void *memmove(void *d, const void *s, size_t n){
    uint8_t *dp=d; const uint8_t *sp=s;
    if(dp<sp) while(n--) *dp++=*sp++;
    else { dp+=n; sp+=n; while(n--) *--dp=*--sp; }
    return d; }
void *memset(void *d, int c, size_t n){ uint8_t *p=d; while(n--) *p++=(uint8_t)c; return d; }
int memcmp(const void *a, const void *b, size_t n){
    const uint8_t *x=a,*y=b; for(;n;n--,x++,y++) if(*x!=*y) return *x-*y; return 0; }
size_t strlen(const char *s){ size_t n=0; while(s[n]) n++; return n; }
