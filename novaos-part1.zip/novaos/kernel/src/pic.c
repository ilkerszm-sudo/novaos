#include <stdint.h>
#include "pic.h"
#include "io.h"
#define PIC1 0x20
#define PIC2 0xA0
/* Remap IRQs 0-15 to vectors 32-47 (0-31 are CPU exceptions); mask everything. */
void pic_init(void){
    outb(PIC1,0x11); io_wait(); outb(PIC2,0x11); io_wait();
    outb(PIC1+1,0x20); io_wait(); outb(PIC2+1,0x28); io_wait();
    outb(PIC1+1,0x04); io_wait(); outb(PIC2+1,0x02); io_wait();
    outb(PIC1+1,0x01); io_wait(); outb(PIC2+1,0x01); io_wait();
    outb(PIC1+1,0xFB);            /* all masked except cascade (IRQ2) */
    outb(PIC2+1,0xFF);
}
void pic_eoi(int irq){ if(irq>=8) outb(PIC2,0x20); outb(PIC1,0x20); }
void pic_unmask(int irq){
    uint16_t port = irq<8 ? PIC1+1 : PIC2+1; if(irq>=8) irq-=8;
    outb(port, inb(port) & ~(1<<irq));
}
