#include "pit.h"
#include "idt.h"
#include "io.h"
#include "cpu.h"
static volatile uint64_t ticks;
static uint32_t pit_hz;
static void pit_irq(struct regs *r){ (void)r; ticks++; /* scheduler hook goes here (next part) */ }
void pit_init(uint32_t hz){
    pit_hz = hz;
    uint32_t div = 1193182 / hz;
    outb(0x43, 0x36);                     /* channel 0, lobyte/hibyte, mode 3 */
    outb(0x40, div & 0xFF); outb(0x40, div >> 8);
    irq_register(0, pit_irq);
}
uint64_t pit_ticks(void){ return ticks; }
void pit_sleep_ms(uint64_t ms){
    uint64_t end = ticks + (ms * pit_hz + 999) / 1000;
    while(ticks < end) hlt();
}
