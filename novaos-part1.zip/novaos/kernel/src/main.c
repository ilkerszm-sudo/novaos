#include <stdint.h>
#include <stdbool.h>
#include "limine.h"
#include "serial.h"
#include "kprintf.h"
#include "gdt.h"
#include "idt.h"
#include "pic.h"
#include "pit.h"
#include "pmm.h"
#include "panic.h"
#include "cpu.h"

/* ---- Limine requests: the bootloader fills these in before jumping to kmain ---- */
__attribute__((used, section(".limine_requests"))) static volatile LIMINE_BASE_REVISION(2);
__attribute__((used, section(".limine_requests"))) static volatile struct limine_memmap_request memmap_req =
    { .id = LIMINE_MEMMAP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests"))) static volatile struct limine_hhdm_request hhdm_req =
    { .id = LIMINE_HHDM_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests"))) static volatile struct limine_framebuffer_request fb_req =
    { .id = LIMINE_FRAMEBUFFER_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests_start"))) static volatile LIMINE_REQUESTS_START_MARKER;
__attribute__((used, section(".limine_requests_end"))) static volatile LIMINE_REQUESTS_END_MARKER;

void kmain(void){
    serial_init();
    kprintf("\n=== NovaOS booting (x86_64) ===\n");
    if(!LIMINE_BASE_REVISION_SUPPORTED) panic("Limine base revision not supported");
    if(!memmap_req.response || !hhdm_req.response) panic("Missing Limine memmap/HHDM response");

    gdt_init();   kprintf("[ok] GDT + TSS\n");
    idt_init();   kprintf("[ok] IDT (exceptions 0-31, IRQs 32-47)\n");
    pic_init();   kprintf("[ok] PIC remapped\n");

    pmm_init(memmap_req.response, hhdm_req.response->offset);
    kprintf("[ok] PMM: %lu MiB free of %lu MiB tracked\n",
            pmm_free_frames()*4/1024, pmm_total_frames()*4/1024);

    pit_init(100);
    sti();
    kprintf("[ok] PIT @ 100 Hz, interrupts enabled\n");

    /* PMM self-test: allocate, write via HHDM, free. */
    uint64_t f = pmm_alloc();
    *(volatile uint64_t *)PHYS_TO_VIRT(f) = 0xC0FFEE;
    kprintf("[ok] PMM test: frame %lx -> %lx\n", f, *(volatile uint64_t *)PHYS_TO_VIRT(f));
    pmm_free(f);

    /* Prove the video path works: paint a gradient (real graphics come in Milestone 3). */
    if(fb_req.response && fb_req.response->framebuffer_count){
        struct limine_framebuffer *fb = fb_req.response->framebuffers[0];
        for(uint64_t y=0;y<fb->height;y++){
            uint32_t *row = (uint32_t *)((uint8_t *)fb->address + y*fb->pitch);
            for(uint64_t x=0;x<fb->width;x++) row[x] = ((x*255/fb->width)<<16) | ((y*255/fb->height)<<8) | 0x80;
        }
        kprintf("[ok] Framebuffer %lux%lu\n", fb->width, fb->height);
    }

    for(int s=1;s<=3;s++){ pit_sleep_ms(1000); kprintf("tick check: uptime %lu ms\n", pit_ticks()*10); }
    kprintf("Milestone 1 / part 1 complete. Triggering test: uncomment divide-by-zero in main.c to see panic.\n");
    /* volatile int z=0; kprintf("%d", 1/z); */
    for(;;) hlt();
}
