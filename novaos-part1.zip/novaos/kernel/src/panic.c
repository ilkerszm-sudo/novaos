#include "panic.h"
#include "kprintf.h"
#include "cpu.h"
#include "io.h"

static __attribute__((noreturn)) void halt_forever(void){ for(;;){ cli(); hlt(); } }

void panic(const char *fmt, ...){
    cli();
    kprintf("\n*** KERNEL PANIC ***\n");
    va_list ap; va_start(ap, fmt); kvprintf(fmt, ap); va_end(ap);
    kprintf("\nSystem halted.\n");
    halt_forever();
}

void panic_regs(const char *msg, struct regs *r){
    cli();
    kprintf("\n*** KERNEL PANIC: %s ***\n", msg);
    kprintf("vector=%lu err=0x%lx\n", r->int_no, r->err);
    kprintf("RIP=%016lx CS=%04lx RFLAGS=%016lx\n", r->rip, r->cs, r->rflags);
    kprintf("RSP=%016lx SS=%04lx CR2=%016lx\n", r->rsp, r->ss, read_cr2());
    kprintf("RAX=%016lx RBX=%016lx RCX=%016lx\n", r->rax, r->rbx, r->rcx);
    kprintf("RDX=%016lx RSI=%016lx RDI=%016lx\n", r->rdx, r->rsi, r->rdi);
    kprintf("RBP=%016lx R8 =%016lx R9 =%016lx\n", r->rbp, r->r8, r->r9);
    kprintf("R10=%016lx R11=%016lx R12=%016lx\n", r->r10, r->r11, r->r12);
    kprintf("R13=%016lx R14=%016lx R15=%016lx\nHalted.\n", r->r13, r->r14, r->r15);
    halt_forever();
}
