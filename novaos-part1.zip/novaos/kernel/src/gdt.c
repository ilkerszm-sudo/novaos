#include "gdt.h"
#include <stdint.h>
#include <stddef.h>
#include "string.h"

/*
 * GDT layout is dictated by SYSCALL/SYSRET (STAR MSR, set up with the syscall layer):
 *   SYSCALL: CS = STAR[47:32] = 0x08, SS = +8  = 0x10
 *   SYSRET : SS = STAR[63:48]+8, CS = +16  with base 0x10 -> SS=0x18, CS=0x20
 * hence order: null, kcode, kdata, udata, ucode, TSS.
 */
struct gdt_entry { uint16_t limit_lo, base_lo; uint8_t base_mid, access, gran, base_hi; } __attribute__((packed));
struct tss_desc  { uint16_t limit_lo, base_lo; uint8_t base_mid, access, gran, base_hi; uint32_t base_up, zero; } __attribute__((packed));
struct gdtr      { uint16_t limit; uint64_t base; } __attribute__((packed));
struct tss {
    uint32_t r0; uint64_t rsp0, rsp1, rsp2, r1; uint64_t ist[7]; uint64_t r2; uint16_t r3, iopb;
} __attribute__((packed));

static struct { struct gdt_entry e[5]; struct tss_desc tss; } __attribute__((packed, aligned(16))) gdt;
static struct tss tss;
static uint8_t df_stack[8192] __attribute__((aligned(16)));   /* IST1: double-fault stack */
static uint8_t ring0_stack[16384] __attribute__((aligned(16)));

static void set_entry(int i, uint8_t access, uint8_t gran){
    gdt.e[i] = (struct gdt_entry){ .limit_lo=0xFFFF, .access=access, .gran=gran };  /* base/limit ignored in 64-bit */
}

void tss_set_rsp0(uint64_t rsp0){ tss.rsp0 = rsp0; }

void gdt_init(void){
    memset(&gdt, 0, sizeof gdt);
    set_entry(1, 0x9A, 0xA0);   /* kernel code: present, ring0, exec/read, L=1 */
    set_entry(2, 0x92, 0xC0);   /* kernel data */
    set_entry(3, 0xF2, 0xC0);   /* user data  (DPL3) */
    set_entry(4, 0xFA, 0xA0);   /* user code  (DPL3, L=1) */

    memset(&tss, 0, sizeof tss);
    tss.rsp0 = (uint64_t)ring0_stack + sizeof ring0_stack;
    tss.ist[0] = (uint64_t)df_stack + sizeof df_stack;
    tss.iopb = sizeof tss;
    uint64_t b = (uint64_t)&tss;
    gdt.tss = (struct tss_desc){ .limit_lo=sizeof tss-1, .base_lo=b&0xFFFF, .base_mid=(b>>16)&0xFF,
        .access=0x89, .gran=0, .base_hi=(b>>24)&0xFF, .base_up=(uint32_t)(b>>32) };

    struct gdtr g = { sizeof gdt - 1, (uint64_t)&gdt };
    /* Load GDT, reload CS via a far return, reload data segments, load TR. */
    __asm__ volatile(
        "lgdt %0\n"
        "pushq $0x08\n"
        "lea 1f(%%rip), %%rax\n"
        "pushq %%rax\n"
        "lretq\n"
        "1:\n"
        "mov $0x10, %%ax\n"
        "mov %%ax, %%ds\n mov %%ax, %%es\n mov %%ax, %%ss\n"
        "xor %%ax, %%ax\n mov %%ax, %%fs\n mov %%ax, %%gs\n"
        "mov $0x28, %%ax\n"
        "ltr %%ax\n"
        : : "m"(g) : "rax", "memory");
}
