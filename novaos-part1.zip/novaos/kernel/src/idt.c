#include "idt.h"
#include "pic.h"
#include "panic.h"
#include "kprintf.h"

struct idt_entry { uint16_t off_lo, sel; uint8_t ist, attr; uint16_t off_mid; uint32_t off_hi, zero; } __attribute__((packed));
struct idtr { uint16_t limit; uint64_t base; } __attribute__((packed));

static struct idt_entry idt[256] __attribute__((aligned(16)));
static irq_handler_t irq_handlers[16];
extern void *isr_stub_table[];   /* 48 stubs from isr_stubs.asm */

static const char *exc_names[32] = {
 "Divide Error","Debug","NMI","Breakpoint","Overflow","Bound Range","Invalid Opcode","Device Not Available",
 "Double Fault","Coprocessor Overrun","Invalid TSS","Segment Not Present","Stack Fault","General Protection",
 "Page Fault","Reserved","x87 FP","Alignment Check","Machine Check","SIMD FP","Virtualization","Control Protection",
 "Reserved","Reserved","Reserved","Reserved","Reserved","Reserved","Hypervisor Injection","VMM Comm","Security","Reserved"
};

static void set_gate(int v, void *h, uint8_t ist){
    uint64_t a = (uint64_t)h;
    idt[v] = (struct idt_entry){ .off_lo=a&0xFFFF, .sel=0x08, .ist=ist, .attr=0x8E,   /* present, DPL0, interrupt gate */
                                 .off_mid=(a>>16)&0xFFFF, .off_hi=(uint32_t)(a>>32) };
}

void idt_init(void){
    for(int i=0;i<48;i++) set_gate(i, isr_stub_table[i], i==8 ? 1 : 0);  /* #DF uses IST1 */
    struct idtr r = { sizeof idt - 1, (uint64_t)idt };
    __asm__ volatile("lidt %0" : : "m"(r));
}

void irq_register(int irq, irq_handler_t h){ irq_handlers[irq] = h; pic_unmask(irq); }

/* Called from isr_common with a pointer to the saved register frame. */
void isr_handler(struct regs *r){
    if(r->int_no < 32){
        panic_regs(exc_names[r->int_no], r);
    } else if(r->int_no < 48){
        int irq = (int)r->int_no - 32;
        if(irq_handlers[irq]) irq_handlers[irq](r);
        pic_eoi(irq);
    }
}
