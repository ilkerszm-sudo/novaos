#include <stdint.h>
#include <stdbool.h>
#include "kprintf.h"
#include "serial.h"

/* Single output sink for now; Milestone 3 adds a framebuffer console here. */
static void out(char c){ serial_putc(c); }

static void print_u(uint64_t v, unsigned base, bool upper, int width, char pad, bool neg){
    char buf[24]; int n=0;
    const char *dig = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    do { buf[n++] = dig[v % base]; v /= base; } while(v);
    if(neg) { if(pad=='0'){ out('-'); width--; } else buf[n++]='-'; }
    for(int i=n; i<width; i++) out(pad);
    while(n) out(buf[--n]);
}

void kvprintf(const char *f, va_list ap){
    for(; *f; f++){
        if(*f!='%'){ out(*f); continue; }
        f++;
        char pad=' '; int width=0, lng=0;
        if(*f=='0'){ pad='0'; f++; }
        while(*f>='0' && *f<='9'){ width = width*10 + (*f-'0'); f++; }
        while(*f=='l'){ lng++; f++; }
        switch(*f){
        case 'c': out((char)va_arg(ap,int)); break;
        case 's': { const char *s=va_arg(ap,const char*); if(!s) s="(null)";
                    int len=0; while(s[len]) len++;
                    for(int i=len;i<width;i++) out(' ');
                    while(*s) out(*s++); } break;
        case 'd': case 'i': { int64_t v = lng ? va_arg(ap,long) : va_arg(ap,int);
                    bool neg = v<0; print_u(neg ? (uint64_t)-v : (uint64_t)v,10,false,width,pad,neg); } break;
        case 'u': print_u(lng ? va_arg(ap,unsigned long) : va_arg(ap,unsigned),10,false,width,pad,false); break;
        case 'x': case 'X': print_u(lng ? va_arg(ap,unsigned long) : va_arg(ap,unsigned),16,*f=='X',width,pad,false); break;
        case 'p': out('0'); out('x'); print_u((uint64_t)va_arg(ap,void*),16,false,16,'0',false); break;
        case '%': out('%'); break;
        default:  out('%'); out(*f); break;
        }
    }
}
void kprintf(const char *fmt, ...){ va_list ap; va_start(ap,fmt); kvprintf(fmt,ap); va_end(ap); }
