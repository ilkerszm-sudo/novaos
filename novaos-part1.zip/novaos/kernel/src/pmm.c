#include "pmm.h"
#include "string.h"
#include "kprintf.h"
#include "panic.h"

/*
 * Bitmap physical memory manager: 1 bit per 4K frame (1 = used).
 * The bitmap lives inside the first big-enough usable region and is accessed
 * through Limine's higher-half direct map (HHDM). Everything below 1 MiB is
 * never handed out (legacy/BIOS area, avoids frame 0 == "OOM" ambiguity).
 */
uint64_t hhdm_offset;
static uint8_t *bitmap;
static size_t total_frames, bitmap_bytes, nfree, hint;

static inline void mark_used(size_t i){ bitmap[i>>3] |=  (1u<<(i&7)); }
static inline void mark_free(size_t i){ bitmap[i>>3] &= ~(1u<<(i&7)); }
static inline int  is_used(size_t i){ return bitmap[i>>3] & (1u<<(i&7)); }

void pmm_init(struct limine_memmap_response *mm, uint64_t hhdm){
    hhdm_offset = hhdm;
    uint64_t top = 0;
    for(uint64_t i=0;i<mm->entry_count;i++){
        struct limine_memmap_entry *e = mm->entries[i];
        if(e->type==LIMINE_MEMMAP_USABLE && e->base+e->length>top) top=e->base+e->length;
    }
    total_frames = top / PAGE_SIZE;
    bitmap_bytes = (total_frames + 7) / 8;
    uint64_t bm_len = (bitmap_bytes + PAGE_SIZE-1) & ~(PAGE_SIZE-1);

    uint64_t bm_phys = 0;
    for(uint64_t i=0;i<mm->entry_count && !bm_phys;i++){
        struct limine_memmap_entry *e = mm->entries[i];
        if(e->type==LIMINE_MEMMAP_USABLE && e->base>=0x100000 && e->length>=bm_len) bm_phys=e->base;
    }
    if(!bm_phys) panic("pmm: no region large enough for bitmap (%lu bytes)", bm_len);
    bitmap = PHYS_TO_VIRT(bm_phys);
    memset(bitmap, 0xFF, bitmap_bytes);            /* start with everything used */

    for(uint64_t i=0;i<mm->entry_count;i++){
        struct limine_memmap_entry *e = mm->entries[i];
        if(e->type!=LIMINE_MEMMAP_USABLE) continue;
        uint64_t s = e->base < 0x100000 ? 0x100000 : e->base, end = e->base + e->length;
        for(uint64_t a=(s+PAGE_SIZE-1)&~(PAGE_SIZE-1); a+PAGE_SIZE<=end; a+=PAGE_SIZE){ mark_free(a/PAGE_SIZE); nfree++; }
    }
    for(uint64_t a=bm_phys; a<bm_phys+bm_len; a+=PAGE_SIZE){ mark_used(a/PAGE_SIZE); nfree--; }  /* protect bitmap */
    hint = 0x100000 / PAGE_SIZE;
}

uint64_t pmm_alloc(void){
    for(size_t n=0;n<total_frames;n++){
        size_t i = (hint + n) % total_frames;
        if(!is_used(i)){ mark_used(i); nfree--; hint=i+1; return (uint64_t)i*PAGE_SIZE; }
    }
    return 0;
}
void pmm_free(uint64_t phys){
    size_t i = phys / PAGE_SIZE;
    if(i>=total_frames || !is_used(i)) panic("pmm_free: bad/double free of %lx", phys);
    mark_free(i); nfree++; if(i<hint) hint=i;
}
size_t pmm_free_frames(void){ return nfree; }
size_t pmm_total_frames(void){ return total_frames; }
