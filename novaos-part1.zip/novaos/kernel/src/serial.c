#include "serial.h"
#include "io.h"
#define COM1 0x3F8
/* 115200 8N1, FIFO on. Polled TX is fine for debug output. */
void serial_init(void){
    outb(COM1+1, 0x00);          /* disable interrupts */
    outb(COM1+3, 0x80);          /* DLAB on */
    outb(COM1+0, 0x01); outb(COM1+1, 0x00);   /* divisor 1 = 115200 baud */
    outb(COM1+3, 0x03);          /* 8 bits, no parity, 1 stop */
    outb(COM1+2, 0xC7);          /* enable FIFO */
    outb(COM1+4, 0x0B);          /* RTS/DSR set */
}
void serial_putc(char c){
    if(c=='\n') serial_putc('\r');
    while(!(inb(COM1+5) & 0x20)) ;
    outb(COM1, (uint8_t)c);
}
