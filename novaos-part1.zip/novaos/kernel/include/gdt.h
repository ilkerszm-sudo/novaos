#pragma once
#include <stdint.h>
#define GDT_KCODE 0x08
#define GDT_KDATA 0x10
#define GDT_UDATA 0x1B   /* 0x18 | RPL3 */
#define GDT_UCODE 0x23   /* 0x20 | RPL3 */
void gdt_init(void);
void tss_set_rsp0(uint64_t rsp0);   /* used by the scheduler for ring3->0 stacks */
