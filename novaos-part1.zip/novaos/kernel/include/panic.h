#pragma once
#include "cpu.h"
__attribute__((noreturn)) void panic(const char *fmt, ...);
__attribute__((noreturn)) void panic_regs(const char *msg, struct regs *r);
