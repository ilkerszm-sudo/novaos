#pragma once
#include <stdint.h>
/* Register frame pushed by isr_stubs.asm (lowest address first). */
struct regs {
    uint64_t r15,r14,r13,r12,r11,r10,r9,r8,rbp,rdi,rsi,rdx,rcx,rbx,rax;
    uint64_t int_no, err;
    uint64_t rip, cs, rflags, rsp, ss;   /* pushed by the CPU */
};
static inline void sti(void){ __asm__ volatile("sti"); }
static inline void cli(void){ __asm__ volatile("cli"); }
static inline void hlt(void){ __asm__ volatile("hlt"); }
