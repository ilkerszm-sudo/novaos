#pragma once
#include <stdint.h>
#include <stddef.h>
#include "limine.h"
#define PAGE_SIZE 4096ULL
extern uint64_t hhdm_offset;
#define PHYS_TO_VIRT(p) ((void *)((uint64_t)(p) + hhdm_offset))
#define VIRT_TO_PHYS(v) ((uint64_t)(v) - hhdm_offset)   /* HHDM addresses only */
void     pmm_init(struct limine_memmap_response *mm, uint64_t hhdm);
uint64_t pmm_alloc(void);            /* returns physical addr of a 4K frame, 0 on OOM */
void     pmm_free(uint64_t phys);
size_t   pmm_free_frames(void);
size_t   pmm_total_frames(void);
