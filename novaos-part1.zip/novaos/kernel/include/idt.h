#pragma once
#include "cpu.h"
typedef void (*irq_handler_t)(struct regs *);
void idt_init(void);
void irq_register(int irq, irq_handler_t h);   /* irq = 0..15 */
