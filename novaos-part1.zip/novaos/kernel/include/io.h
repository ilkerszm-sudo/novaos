#pragma once
#include <stdint.h>
static inline void outb(uint16_t p, uint8_t v){ __asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p)); }
static inline uint8_t inb(uint16_t p){ uint8_t v; __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p)); return v; }
static inline void io_wait(void){ outb(0x80, 0); }
static inline uint64_t read_cr2(void){ uint64_t v; __asm__ volatile("mov %%cr2,%0":"=r"(v)); return v; }
