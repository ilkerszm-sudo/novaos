#pragma once
#include <stdint.h>
void pit_init(uint32_t hz);
uint64_t pit_ticks(void);
void pit_sleep_ms(uint64_t ms);
