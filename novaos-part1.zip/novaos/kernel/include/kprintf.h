#pragma once
#include <stdarg.h>
/* Supports %c %s %d %i %u %x %X %p, width/0-pad, and l/ll length modifiers. */
void kprintf(const char *fmt, ...);
void kvprintf(const char *fmt, va_list ap);
